

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author master
 */
public class LinkedQueue<E> {
    private SinglyLinkedList<E>list=new SinglyLinkedList();
    public LinkedQueue(){}
    public boolean isEmpty(){return list.isEmpty();}
    public void enqueue(E element){list.addLast(element);}
    public E first(){return list.first();}
    public E dequeue(){return list.removeFirst();}
    public int size(){return list.size();}
}
