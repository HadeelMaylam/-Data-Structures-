


/**
 *
 * @author Dell
 */
public class Tree {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         BinaryTree<Integer> bt = new BinaryTree();
        System.out.println(bt.getSize());
        TNode<Integer> r = bt.addRoot(5);
        TNode<Integer> lc = bt.addLeft(r, 8);
        TNode<Integer> rc = bt.addRight(r, 9);
        System.out.println(bt.isRoot(r));
        System.out.println(bt.isRoot(lc));
        System.out.println(lc.getItem());
        System.out.println(bt.isEmpty());
        System.out.println(bt.isExternal(rc));
        System.out.println(bt.isInternal(lc));
        bt.addLeft(lc, 100);
        bt.addLeft(rc, 300);
        System.out.println(bt.getSize());
        System.out.println(bt.left(lc).getItem() + 30);
        System.out.println("hight is "+bt.height());
        bt.breadth_first(bt.getRoot());


  

        
    }
    
}
